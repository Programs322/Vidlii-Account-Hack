//UNUSED
findString = function findText(text) {
  if(window.find(text)){
    document.documentElement.innerHTML = '';
    document.documentElement.innerHTML = '';
    document.documentElement.scrollTop = 0;
  };
}

findString("");

//BLOCK A CERTAIN MALICIOUS WEBSITE
findURL = function changeURL(text){
  var current = window.location.href;
  if(current === text){
    window.open(chrome.runtime.getURL('.html'));
	alert('This subdomain has been detected as malicious!')
  }
}

//BLOCK THE ENTIRE MALICIOUS WEBSITE
findAllURL = function changeAllURL(text){
  var current = window.location.href;
  if(current.startsWith(text)){
    window.open(chrome.runtime.getURL('no.html'));
	alert('This website has been detected as malicious!')
  }
}

//Possibly malicious subdomains
findURL("https://chrome.google.com/webstore/detail/snapchat-for-pc/cdfggipgleplnaoolkbffigcmffncggj");
findURL("https://chrome.google.com/webstore/detail/run-snapchat%EF%B8%8F-on-your-pc/hbebllbphabhnmbfkpmakdoobemiiehh");
//Possibly malicious domains
findAllURL("https://www.pcoptimizerpro.com");
findAllURL("https://en.softonic.com");
findAllURL("https://www.protegent360.com");
findAllURL("https://www.bonzi.link");
findAllURL("http://www.bonzi.link");
findAllURL("http://www.bonzi.link");
findAllURL("http://www.bonzi.link");
findAllURL("https://xstr312.weebly.com/");